-- ProLog Minimal Database Schema
-- PostgreSQL 12+

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    last_login TIMESTAMP
);

-- Cases (using JSONB for flexibility)
CREATE TABLE cases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    patient_id VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    hospital VARCHAR(255),
    data JSONB NOT NULL, -- All procedure data stored here
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Sessions
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(500) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_cases_user ON cases(user_id);
CREATE INDEX idx_cases_date ON cases(date);
CREATE INDEX idx_sessions_token ON sessions(token);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- Auto-update timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER cases_updated 
    BEFORE UPDATE ON cases
    FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- Cleanup expired sessions (run daily via cron)
CREATE OR REPLACE FUNCTION cleanup_sessions()
RETURNS void AS $$
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Default admin user (username: admin, password: changeme123)
-- Hash generated with: SELECT crypt('changeme123', gen_salt('bf', 10));
INSERT INTO users (username, email, password_hash, full_name) VALUES (
    'admin',
    'admin@prolog.local',
    '$2a$10$rKvV7QAhDyFz5Z6g6YxXVeE6kXzKxQnGJ8vQXH0wYJ7FzJ8vQXH0w',
    'Administrator'
) ON CONFLICT DO NOTHING;

-- Grant permissions to prolog user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO prolog_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO prolog_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO prolog_user;
