#!/bin/bash
# ProLog Automated Backup Script
# Backs up PostgreSQL database and creates timestamped archive

set -e

BACKUP_DIR="/var/backups/prolog"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="prolog_backup_${TIMESTAMP}.sql.gz"
RETENTION_DAYS=30

# Ensure backup directory exists
mkdir -p "$BACKUP_DIR"

# Database credentials (read from backend .env)
DB_NAME="prolog"
DB_USER="prolog_user"

# Get password from .env file
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DB_PASSWORD=$(grep DB_PASSWORD "$SCRIPT_DIR/backend/.env" | cut -d '=' -f2)

export PGPASSWORD="$DB_PASSWORD"

echo "[$(date)] Starting ProLog backup..."

# Dump database
pg_dump -h localhost -U "$DB_USER" "$DB_NAME" | gzip > "$BACKUP_DIR/$BACKUP_FILE"

# Check if backup was successful
if [ $? -eq 0 ]; then
    SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
    echo "[$(date)] ✓ Backup completed: $BACKUP_FILE ($SIZE)"
    
    # Log to syslog
    logger -t prolog-backup "Database backup completed: $BACKUP_FILE ($SIZE)"
else
    echo "[$(date)] ✗ Backup failed!"
    logger -t prolog-backup -p user.err "Database backup FAILED"
    exit 1
fi

# Clean up old backups (keep last 30 days)
echo "[$(date)] Cleaning up backups older than $RETENTION_DAYS days..."
find "$BACKUP_DIR" -name "prolog_backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete

# Count remaining backups
BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/prolog_backup_*.sql.gz 2>/dev/null | wc -l)
echo "[$(date)] Total backups: $BACKUP_COUNT"

# Unset password
unset PGPASSWORD

echo "[$(date)] Backup process complete"
