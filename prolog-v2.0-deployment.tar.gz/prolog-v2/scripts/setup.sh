#!/bin/bash
# ProLog Automated Setup Script
# Run with: sudo ./setup.sh

set -e  # Exit on error

echo "=========================================="
echo "ProLog Self-Hosted Setup"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (sudo ./setup.sh)"
    exit 1
fi

# Get actual user (not root)
ACTUAL_USER=${SUDO_USER:-$USER}
INSTALL_DIR=$(pwd)

echo ""
echo "Step 1/7: Installing system dependencies..."
apt update
apt install -y nodejs npm postgresql nginx

echo ""
echo "Step 2/7: Installing PM2..."
npm install -g pm2

echo ""
echo "Step 3/7: Setting up PostgreSQL..."
# Generate random password
DB_PASSWORD=$(openssl rand -base64 32)

# Create database and user
sudo -u postgres psql <<EOF
CREATE DATABASE prolog;
CREATE USER prolog_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE prolog TO prolog_user;
\q
EOF

# Load schema
sudo -u postgres psql prolog < database/init.sql

echo "✓ Database created"
echo "  Database: prolog"
echo "  User: prolog_user"
echo "  Password: $DB_PASSWORD"

echo ""
echo "Step 4/7: Configuring backend..."
cd backend

# Install dependencies
npm install

# Generate JWT secret
JWT_SECRET=$(openssl rand -base64 64 | tr -d '\n')

# Create .env file
cat > .env <<EOF
NODE_ENV=production
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=prolog
DB_USER=prolog_user
DB_PASSWORD=$DB_PASSWORD
JWT_SECRET=$JWT_SECRET
EOF

echo "✓ Backend configured"

# Start backend with PM2
pm2 delete prolog-api 2>/dev/null || true
pm2 start server.js --name prolog-api
pm2 save
pm2 startup systemd -u $ACTUAL_USER --hp /home/$ACTUAL_USER 2>/dev/null || true

cd ..

echo ""
echo "Step 5/7: Deploying frontend..."
mkdir -p /var/www/prolog
cp frontend/index.html /var/www/prolog/
chown -R www-data:www-data /var/www/prolog

echo "✓ Frontend deployed"

echo ""
echo "Step 6/7: Configuring nginx..."
cp nginx.conf /etc/nginx/sites-available/prolog
ln -sf /etc/nginx/sites-available/prolog /etc/nginx/sites-enabled/prolog
rm -f /etc/nginx/sites-enabled/default

# Test nginx config
nginx -t

# Reload nginx
systemctl reload nginx

echo "✓ Nginx configured"

echo ""
echo "Step 7/7: Setting up backups..."
mkdir -p /var/backups/prolog
chmod +x backup.sh

# Add to crontab for actual user
(sudo -u $ACTUAL_USER crontab -l 2>/dev/null; echo "0 2 * * * $INSTALL_DIR/backup.sh") | sudo -u $ACTUAL_USER crontab -

echo "✓ Daily backups configured (2 AM)"

echo ""
echo "=========================================="
echo "✓ Installation Complete!"
echo "=========================================="
echo ""
echo "Application URL: http://$(hostname -I | awk '{print $1}')"
echo ""
echo "Default Login:"
echo "  Username: admin"
echo "  Password: changeme123"
echo ""
echo "⚠️  IMPORTANT: Change the admin password immediately!"
echo ""
echo "Useful Commands:"
echo "  View logs:        pm2 logs prolog-api"
echo "  Restart backend:  pm2 restart prolog-api"
echo "  Check status:     pm2 status"
echo "  Manual backup:    ./backup.sh"
echo ""
echo "Credentials saved to: $INSTALL_DIR/CREDENTIALS.txt"
echo ""

# Save credentials
cat > CREDENTIALS.txt <<EOF
ProLog Installation Credentials
================================
Installed: $(date)

Database:
  Host: localhost
  Database: prolog
  User: prolog_user
  Password: $DB_PASSWORD

Application:
  URL: http://$(hostname -I | awk '{print $1}')
  Default Username: admin
  Default Password: changeme123

JWT Secret: $JWT_SECRET

⚠️  KEEP THIS FILE SECURE!
EOF

chmod 600 CREDENTIALS.txt
chown $ACTUAL_USER:$ACTUAL_USER CREDENTIALS.txt

echo "Setup complete! Visit the application URL above to get started."
